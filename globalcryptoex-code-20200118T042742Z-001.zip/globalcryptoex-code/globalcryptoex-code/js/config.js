
var ShiftConfig = {
    API_V2_URL: 'wss://api_globalcrypto_prod.alphapoint.com/WSGateway/',
}


var APConfig = {
    showDepositBankDetails: false,
    depositFileUpload: false,
    showWidgetPageNumbers: true,
    showTermsandConditions: true,
    registerFormModal: true,
    showDepositBankDetails: false,
    showBlockTradeUI: true,
    siteTitle: 'Global Crypto Exchange',
    siteName: 'globalcryptoex.com',
    usePagi: false,
    chart_dark: false,
    API_V2_URL: 'wss://api_globalcrypto_prod.alphapoint.com/WSGateway/',
    //API_V2_URL: 'wss://api_shiftforex_staging.alphapoint.com/WSGateway/',
    //MarketDataWS: 'wss://api_demo.alphapoint.com/WSGateway/',
    //TickerDataWS: 'wss://api_demo.alphapoint.com/WSGateway/',
    serversList: [
        'wss://api_shiftforex_staging.alphapoint.com/WSGateway/'
    ],
    useServerSelect: false,
    OperatorId: 1,
    L2UpdateMethod: 2, // this is to use Joe's method of L2 updates
    baseCoin: 'BTC',
    prodPair: 'BTCUSD',
    loginRedirect: 'index.html',
    logoutRedirect: 'index.html',
    defaultLanguage: 'en',
    languagesLocation: 'lang',
    charting_library: 'libs/charting_library_new/',
    showDepthChart: false,
    authy2FA: false,
    authGoogle: true,
    debugging: true,
    useShapeShift: false,
    authGoogleSiteName: 'TraderUI', // this cannot have spaces
    apiKeysLevel: 0,
    withdrawLevel: 0,
    withdrawWidget: 2,
    decimalPlaces: 2,
    decimalPlacesPrice: 2,
    decimalPlacesQty: 8,
    dealPrices: [100, 200, 500, 1000],
    orderbookMaxLines: 30,
    maxLinesWidgets: 14,
    orderBookSideRowCount: 40, // IMPORTANT: this is the row count for each side of the orderbook
    withdrawFee: {
        Bitcoin: {
            BTC: 0.0003
        },
        Litecoin: {
            LTC: 0.001
        }
    },
    sendFee: {
        BTC: 0.0003,
        LTC: 0.001,
    },
    growlerDefaultOptions: {
        allow_dismiss: true,
        width: 'auto',
        delay: 3000,
        align: 'left',
        offset: { from: 'top', amount: 70 },
        left: '70%',
    },
    TwoFACookie: 'UNOAuth',
    useSimMode: false,
    apexSite: false,
    useDepositTemplates: true,
    releaseVersion: 'v1.3.0 r4296',
    optionalNewDepositKeys: false,
};